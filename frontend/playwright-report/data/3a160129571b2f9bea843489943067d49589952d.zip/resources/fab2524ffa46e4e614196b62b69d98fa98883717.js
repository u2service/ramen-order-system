(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__04kpziu._.css","static/chunks/node_modules_next_dist_20wefz_._.js","static/chunks/_102g8o0._.js"],
    source: "entry"
});

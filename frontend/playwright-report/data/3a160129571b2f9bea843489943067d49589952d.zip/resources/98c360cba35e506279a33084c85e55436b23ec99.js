(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/app/pos/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PosPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$pos$2f$PosCheckout$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/pos/PosCheckout.tsx [app-client] (ecmascript)");
"use client";
;
;
function PosPage() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "min-h-screen bg-gray-100",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$pos$2f$PosCheckout$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/app/pos/page.tsx",
            lineNumber: 8,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/pos/page.tsx",
        lineNumber: 7,
        columnNumber: 5
    }, this);
}
_c = PosPage;
var _c;
__turbopack_context__.k.register(_c, "PosPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/pos/PosCheckout.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PosCheckout
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$stripe$2f$stripe$2d$js$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@stripe/stripe-js/lib/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$stripe$2f$stripe$2d$js$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@stripe/stripe-js/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$stripe$2f$react$2d$stripe$2d$js$2f$dist$2f$react$2d$stripe$2e$esm$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@stripe/react-stripe-js/dist/react-stripe.esm.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
;
const API_BASE_URL = ("TURBOPACK compile-time value", "http://localhost:8000/api/v1") || "http://localhost:8000";
const stripePromise = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$stripe$2f$stripe$2d$js$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadStripe"])(("TURBOPACK compile-time value", "pk_test_51RapdqRsffrOeSzJ68CXHTr9im40OArwO0M4Em0iTwu81VGvEHJUAaEAJAEEtrwo4MO9SqFW6wHn85ZHzrlAF3Uh00cSA4e4aW"));
// -------------------------------------------------------------
// ▼ クレジットカード決済入力フォーム (Stripe Elements)
// -------------------------------------------------------------
function StripeCheckoutForm({ amount, onSuccess }) {
    _s();
    const stripe = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$stripe$2f$react$2d$stripe$2d$js$2f$dist$2f$react$2d$stripe$2e$esm$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStripe"])();
    const elements = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$stripe$2f$react$2d$stripe$2d$js$2f$dist$2f$react$2d$stripe$2e$esm$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useElements"])();
    const [isProcessing, setIsProcessing] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [errorMessage, setErrorMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const handleSubmit = async (e)=>{
        e.preventDefault();
        if (!stripe || !elements) return;
        setIsProcessing(true);
        setErrorMessage(null);
        // Stripe 決済の確定処理
        const { error, paymentIntent } = await stripe.confirmPayment({
            elements,
            redirect: 'if_required'
        });
        if (error) {
            setErrorMessage(error.message ?? '決済処理中にエラーが発生しました。');
            setIsProcessing(false);
        } else if (paymentIntent && paymentIntent.status === 'succeeded') {
            // 決済成功時の処理を実行（親コンポーネント側の完了処理を呼び出す）
            onSuccess();
        } else {
            setIsProcessing(false);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
        onSubmit: handleSubmit,
        className: "space-y-4 mt-2 p-4 border rounded bg-gray-50",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$stripe$2f$react$2d$stripe$2d$js$2f$dist$2f$react$2d$stripe$2e$esm$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PaymentElement"], {}, void 0, false, {
                fileName: "[project]/src/components/pos/PosCheckout.tsx",
                lineNumber: 76,
                columnNumber: 7
            }, this),
            errorMessage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-red-500 text-sm font-semibold",
                children: errorMessage
            }, void 0, false, {
                fileName: "[project]/src/components/pos/PosCheckout.tsx",
                lineNumber: 78,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "submit",
                disabled: !stripe || isProcessing,
                className: "w-full bg-indigo-600 text-white py-3 rounded-lg font-bold text-lg hover:bg-indigo-700 disabled:opacity-50",
                children: isProcessing ? '決済処理中...' : `カードで ¥${amount.toLocaleString()} を支払う`
            }, void 0, false, {
                fileName: "[project]/src/components/pos/PosCheckout.tsx",
                lineNumber: 80,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/pos/PosCheckout.tsx",
        lineNumber: 75,
        columnNumber: 5
    }, this);
}
_s(StripeCheckoutForm, "j3CICSH+hoBhuBa4gJ6+ruSxBRw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$stripe$2f$react$2d$stripe$2d$js$2f$dist$2f$react$2d$stripe$2e$esm$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStripe"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$stripe$2f$react$2d$stripe$2d$js$2f$dist$2f$react$2d$stripe$2e$esm$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useElements"]
    ];
});
_c = StripeCheckoutForm;
function PosCheckout() {
    _s1();
    const [selectedTable, setSelectedTable] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [currentOrder, setCurrentOrder] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [paymentMethod, setPaymentMethod] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('cash');
    const [paidAmount, setPaidAmount] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    // Stripe 決済用 ClientSecret
    const [clientSecret, setClientSecret] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [isCreatingIntent, setIsCreatingIntent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // ▼ 未会計注文が存在する卓番号のリスト
    const [activeTables, setActiveTables] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    // ▼ 未会計の卓一覧をバックエンドから取得
    const fetchActiveTables = async ()=>{
        try {
            const res = await fetch(`${API_BASE_URL}/pos/active-tables`);
            if (res.ok) {
                const data = await res.json();
                setActiveTables(data.active_tables || []);
            }
        } catch (error) {
            console.error("アクティブ卓の取得に失敗しました", error);
        }
    };
    // ▼ 1. 卓選択時に未会計伝票を取得
    const fetchTableOrder = async (tableNum)=>{
        setSelectedTable(tableNum);
        setClientSecret(''); // 卓切り替え時に前回の Stripe 情報をクリア
        try {
            const res = await fetch(`${API_BASE_URL}/pos/tables/${tableNum}`);
            if (res.status === 404) {
                setCurrentOrder(null);
                return;
            }
            if (!res.ok) {
                console.error(`APIエラー: ${res.status}`);
                setCurrentOrder(null);
                return;
            }
            const data = await res.json();
            setCurrentOrder({
                id: data.items[0]?.order_id || 0,
                table_number: data.table_number,
                status: 'pending',
                total_price: data.total_price,
                items: data.items.map((item)=>({
                        ...item,
                        id: item.item_id || item.id
                    }))
            });
            setPaidAmount(0);
        } catch (error) {
            console.error("伝票データの取得に失敗しました", error);
            setCurrentOrder(null);
        }
    };
    // ▼ クレジットカード選択時 または 注文金額変更時に Stripe PaymentIntent を作成
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PosCheckout.useEffect": ()=>{
            if (paymentMethod === 'credit' && currentOrder && currentOrder.total_price > 0) {
                setIsCreatingIntent(true);
                fetch('/api/create-payment-intent', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        amount: currentOrder.total_price
                    })
                }).then({
                    "PosCheckout.useEffect": (res)=>res.json()
                }["PosCheckout.useEffect"]).then({
                    "PosCheckout.useEffect": (data)=>{
                        if (data.clientSecret) {
                            setClientSecret(data.clientSecret);
                        }
                    }
                }["PosCheckout.useEffect"]).catch({
                    "PosCheckout.useEffect": (err)=>{
                        console.error('PaymentIntent 作成失敗:', err);
                    }
                }["PosCheckout.useEffect"]).finally({
                    "PosCheckout.useEffect": ()=>{
                        setIsCreatingIntent(false);
                    }
                }["PosCheckout.useEffect"]);
            }
        }
    }["PosCheckout.useEffect"], [
        paymentMethod,
        currentOrder?.total_price
    ]);
    // ▼ 裏で伝票を最新化する関数[cite: 2]
    const fetchTableOrderSilent = async (tableNum)=>{
        try {
            const res = await fetch(`${API_BASE_URL}/pos/tables/${tableNum}`);
            if (res.status === 404) {
                setCurrentOrder(null);
                fetchActiveTables();
                return;
            }
            if (!res.ok) return;
            const data = await res.json();
            setCurrentOrder({
                id: data.items[0]?.order_id || 0,
                table_number: data.table_number,
                status: 'pending',
                total_price: data.total_price,
                items: data.items.map((item)=>({
                        ...item,
                        id: item.item_id || item.id
                    }))
            });
        } catch (error) {
        // 自動更新時のエラーは静かにスルー[cite: 2]
        }
    };
    // ▼ SSE接続および初期データの取得
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PosCheckout.useEffect": ()=>{
            // 1. 初回の未会計卓一覧を取得
            fetchActiveTables();
            // 2. SSE接続の確立
            const eventSource = new EventSource(`${API_BASE_URL}/orders/events/stream`);
            // サーバーからメッセージを受信した際の処理
            eventSource.onmessage = ({
                "PosCheckout.useEffect": (event)=>{
                    try {
                        const data = JSON.parse(event.data);
                        // 未会計卓一覧の自動更新
                        fetchActiveTables();
                        // 選択中の卓のデータ更新通知が来た場合、または全体更新イベント時に再取得
                        if (selectedTable !== null) {
                            fetchTableOrderSilent(selectedTable);
                        }
                    } catch (error) {
                        console.error("SSEメッセージの解析エラー:", error);
                    }
                }
            })["PosCheckout.useEffect"];
            // カスタムイベント（例: order_updated）を受信する場合の例
            eventSource.addEventListener('order_update', {
                "PosCheckout.useEffect": (event)=>{
                    fetchActiveTables();
                    if (selectedTable !== null) {
                        fetchTableOrderSilent(selectedTable);
                    }
                }
            }["PosCheckout.useEffect"]);
            eventSource.onerror = ({
                "PosCheckout.useEffect": (error)=>{
                    console.error("SSE接続エラーが発生しました:", error);
                // EventSourceは自動的に再接続を試みますが、必要に応じてクローズ処理等を行います
                }
            })["PosCheckout.useEffect"];
            // クリーンアップ（コンポーネントのアンマウント時・卓変更時に切断）
            return ({
                "PosCheckout.useEffect": ()=>{
                    eventSource.close();
                }
            })["PosCheckout.useEffect"];
        }
    }["PosCheckout.useEffect"], [
        selectedTable
    ]);
    // 2. 商品個別の取り消し処理[cite: 2]
    const handleCancelItem = async (itemId, reason)=>{
        if (!currentOrder) return;
        try {
            const res = await fetch(`${API_BASE_URL}/pos/items/${itemId}/cancel`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    cancel_reason: reason
                })
            });
            if (res.ok) {
                fetchTableOrder(currentOrder.table_number);
                fetchActiveTables();
            } else {
                const err = await res.json();
                alert(`取消エラー: ${err.detail}`);
            }
        } catch (error) {
            console.error("キャンセルの通信に失敗しました", error);
        }
    };
    // 3. 商品単位または全額サービス（100%割引・おごり）適用[cite: 2]
    const handleApplyDiscount = async (itemId, isFullComp = false)=>{
        if (!currentOrder) return;
        try {
            const res = await fetch(`${API_BASE_URL}/pos/orders/${currentOrder.id}/discount`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    order_item_id: itemId || null,
                    is_full_comp: isFullComp
                })
            });
            if (res.ok) {
                fetchTableOrder(currentOrder.table_number);
            } else {
                const err = await res.json();
                alert(`サービス適用エラー: ${err.detail}`);
            }
        } catch (error) {
            console.error("割引処理の通信に失敗しました", error);
        }
    };
    // 4. 精算完了処理 (現金)[cite: 2]
    const handleCashCheckout = async ()=>{
        if (!currentOrder || !selectedTable) return;
        if (paidAmount < currentOrder.total_price) {
            alert("お預かり金額が不足しています");
            return;
        }
        try {
            const res = await fetch(`${API_BASE_URL}/pos/checkout/cash`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    table_number: selectedTable,
                    paid_amount: Number(paidAmount)
                })
            });
            if (!res.ok) {
                const errorData = await res.json();
                alert(`会計エラー: ${errorData.detail || '精算処理に失敗しました'}`);
                return;
            }
            const data = await res.json();
            alert(`お会計が完了しました！\nお釣り: ¥${data.change_amount.toLocaleString()}`);
            clearCheckoutState();
        } catch (error) {
            console.error('精算処理中にエラーが発生しました', error);
            alert('サーバーとの通信に失敗しました。');
        }
    };
    // 5. 精算完了処理 (クレジットカード)
    const handleCreditCheckoutSuccess = async ()=>{
        if (!currentOrder || !selectedTable) return;
        try {
            // バックエンド側にもクレジットカード精算成功の通知・伝票クローズリクエストを送る
            // (※バックエンド側でクレジット用のAPIが存在する場合、URLを変更してください)
            const res = await fetch(`${API_BASE_URL}/pos/checkout/cash`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    table_number: selectedTable,
                    paid_amount: currentOrder.total_price
                })
            });
            if (!res.ok) {
                // 例えバックエンドの更新通知でエラーが出てもStripe側の決済は完了しています
                const errorData = await res.json().catch(()=>({}));
                console.warn('バックエンドの伝票クローズ処理でエラー:', errorData);
            }
            alert('クレジットカードでの精算が完了しました！');
            clearCheckoutState();
        } catch (error) {
            console.error('精算通知エラー:', error);
            alert('クレジットカードでの決済は完了しましたが、ステータス更新に失敗しました。');
            clearCheckoutState();
        }
    };
    // 会計完了後の共通クリア処理[cite: 2]
    const clearCheckoutState = ()=>{
        setCurrentOrder(null);
        setSelectedTable(null);
        setPaidAmount(0);
        setClientSecret('');
        fetchActiveTables();
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex h-screen bg-gray-100",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-1/3 p-4 border-r bg-white",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-xl font-bold mb-4",
                        children: "卓一覧・未会計伝票"
                    }, void 0, false, {
                        fileName: "[project]/src/components/pos/PosCheckout.tsx",
                        lineNumber: 376,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-3 gap-4",
                        children: [
                            1,
                            2,
                            3,
                            4,
                            5,
                            6,
                            7,
                            8,
                            9,
                            10
                        ].map((tableNum)=>{
                            const hasOrder = activeTables.includes(tableNum);
                            const isSelected = selectedTable === tableNum;
                            let buttonStyle = "bg-gray-50 text-gray-700 border-gray-300";
                            if (isSelected) {
                                buttonStyle = "bg-blue-600 text-white border-blue-700 shadow-lg";
                            } else if (hasOrder) {
                                buttonStyle = "bg-orange-500 text-white border-orange-600 animate-pulse";
                            }
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>fetchTableOrder(tableNum),
                                className: `p-6 border rounded-lg text-lg font-bold transition-all relative ${buttonStyle}`,
                                children: [
                                    "卓 ",
                                    tableNum,
                                    hasOrder && !isSelected && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "absolute top-1 right-2 text-xs bg-red-600 text-white px-1.5 py-0.5 rounded-full",
                                        children: "未会計"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                        lineNumber: 397,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, tableNum, true, {
                                fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                lineNumber: 390,
                                columnNumber: 15
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "[project]/src/components/pos/PosCheckout.tsx",
                        lineNumber: 377,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/pos/PosCheckout.tsx",
                lineNumber: 375,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-2/3 p-4 flex flex-col justify-between",
                children: currentOrder ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex justify-between items-center mb-4 border-b pb-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                            className: "text-2xl font-bold",
                                            children: [
                                                "卓 No. ",
                                                currentOrder.table_number,
                                                " 伝票"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                            lineNumber: 413,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: ()=>handleApplyDiscount(undefined, true),
                                            className: "bg-purple-600 text-white px-4 py-2 rounded text-sm font-semibold hover:bg-purple-700",
                                            children: "全額サービス（大将のおごり）"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                            lineNumber: 414,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                    lineNumber: 412,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-3 max-h-[50vh] overflow-y-auto",
                                    children: currentOrder.items.map((item, index)=>{
                                        const optionsTotal = item.options?.reduce((sum, opt)=>sum + (opt.price || 0), 0) || 0;
                                        const baseUnitPrice = Math.max(0, item.price - item.discount_amount);
                                        const subtotal = (baseUnitPrice + optionsTotal) * item.quantity;
                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "p-3 bg-white border rounded flex justify-between items-center",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "font-bold text-lg",
                                                            children: [
                                                                item.product_name,
                                                                " @",
                                                                item.price.toLocaleString(),
                                                                "円"
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                                            lineNumber: 432,
                                                            columnNumber: 25
                                                        }, this),
                                                        item.options && item.options.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "text-sm text-gray-500",
                                                            children: item.options.map((o)=>o.option_name || o.name).join(', ')
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                                            lineNumber: 437,
                                                            columnNumber: 27
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            children: item.options && item.options.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                                                className: "mt-2 pl-3 text-sm text-gray-600 space-y-0.5 border-l-2 border-orange-300 bg-gray-50 p-2 rounded",
                                                                children: item.options.map((opt, optIdx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                                        className: "flex justify-between items-center text-xs",
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                children: [
                                                                                    "・",
                                                                                    opt.option_name || opt.name
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                                                                lineNumber: 447,
                                                                                columnNumber: 35
                                                                            }, this),
                                                                            opt.price > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                className: "text-gray-500",
                                                                                children: [
                                                                                    "+",
                                                                                    opt.price
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                                                                lineNumber: 449,
                                                                                columnNumber: 37
                                                                            }, this)
                                                                        ]
                                                                    }, optIdx, true, {
                                                                        fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                                                        lineNumber: 446,
                                                                        columnNumber: 33
                                                                    }, this))
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                                                lineNumber: 444,
                                                                columnNumber: 29
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                                            lineNumber: 442,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "text-sm font-semibold text-blue-600 mt-1",
                                                            children: [
                                                                "数量：",
                                                                item.quantity,
                                                                " 小計：¥",
                                                                subtotal.toLocaleString()
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                                            lineNumber: 457,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                                    lineNumber: 431,
                                                    columnNumber: 23
                                                }, this),
                                                item.status !== 'cancelled' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex space-x-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: ()=>handleApplyDiscount(item.id, false),
                                                            className: "px-2 py-1 bg-yellow-500 text-white text-xs rounded hover:bg-yellow-600",
                                                            children: "単品サービス"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                                            lineNumber: 464,
                                                            columnNumber: 27
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: ()=>handleCancelItem(item.id, 'customer_mistake'),
                                                            className: "px-2 py-1 bg-red-500 text-white text-xs rounded hover:bg-red-600",
                                                            children: "客都合取消"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                                            lineNumber: 470,
                                                            columnNumber: 27
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: ()=>handleCancelItem(item.id, 'kitchen_error'),
                                                            className: "px-2 py-1 bg-gray-700 text-white text-xs rounded hover:bg-gray-800",
                                                            children: "厨房ミス/廃棄"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                                            lineNumber: 476,
                                                            columnNumber: 27
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                                    lineNumber: 463,
                                                    columnNumber: 25
                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-red-500 font-bold",
                                                    children: "取消済"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                                    lineNumber: 484,
                                                    columnNumber: 25
                                                }, this)
                                            ]
                                        }, item.item_id || item.id || `item-${index}`, true, {
                                            fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                            lineNumber: 430,
                                            columnNumber: 21
                                        }, this);
                                    })
                                }, void 0, false, {
                                    fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                    lineNumber: 423,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/pos/PosCheckout.tsx",
                            lineNumber: 411,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-white p-6 border rounded-lg shadow-md mt-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex justify-between text-2xl font-bold mb-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: "お支払い総合計:"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                            lineNumber: 495,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-red-600",
                                            children: [
                                                "¥",
                                                currentOrder.total_price.toLocaleString()
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                            lineNumber: 496,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                    lineNumber: 494,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex gap-4 mb-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: ()=>setPaymentMethod('cash'),
                                            className: `flex-1 py-3 font-bold rounded ${paymentMethod === 'cash' ? 'bg-green-600 text-white' : 'bg-gray-200'}`,
                                            children: "現金決済"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                            lineNumber: 501,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: ()=>setPaymentMethod('credit'),
                                            className: `flex-1 py-3 font-bold rounded ${paymentMethod === 'credit' ? 'bg-indigo-600 text-white' : 'bg-gray-200'}`,
                                            children: "クレジットカード (Stripe)"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                            lineNumber: 507,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                    lineNumber: 500,
                                    columnNumber: 15
                                }, this),
                                paymentMethod === 'cash' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-3",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: "font-bold",
                                                    children: "お預かり金額:"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                                    lineNumber: 519,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    type: "number",
                                                    value: paidAmount,
                                                    onChange: (e)=>setPaidAmount(Number(e.target.value)),
                                                    className: "border p-2 rounded text-xl w-48 text-right"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                                    lineNumber: 520,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                            lineNumber: 518,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-lg font-semibold",
                                            children: [
                                                "お釣り: ",
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-blue-600 font-bold",
                                                    children: [
                                                        "¥",
                                                        Math.max(0, paidAmount - currentOrder.total_price).toLocaleString()
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                                    lineNumber: 528,
                                                    columnNumber: 26
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                            lineNumber: 527,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: handleCashCheckout,
                                            className: "w-full bg-green-600 text-white text-xl font-bold py-3 rounded hover:bg-green-700",
                                            children: "現金精算を確定する"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                            lineNumber: 530,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                    lineNumber: 517,
                                    columnNumber: 17
                                }, this),
                                paymentMethod === 'credit' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: isCreatingIntent ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-center text-gray-500 py-4",
                                        children: "Stripe 決済画面を読み込み中..."
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                        lineNumber: 543,
                                        columnNumber: 21
                                    }, this) : clientSecret ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$stripe$2f$react$2d$stripe$2d$js$2f$dist$2f$react$2d$stripe$2e$esm$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Elements"], {
                                        stripe: stripePromise,
                                        options: {
                                            clientSecret,
                                            locale: 'ja',
                                            // ▼ Link や自動補完機能を無効化し、毎回新規入力画面にする設定
                                            appearance: {
                                                theme: 'stripe'
                                            }
                                        },
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(StripeCheckoutForm, {
                                            amount: currentOrder.total_price,
                                            onSuccess: handleCreditCheckoutSuccess
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                            lineNumber: 556,
                                            columnNumber: 23
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                        lineNumber: 545,
                                        columnNumber: 21
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-center text-red-500 py-4",
                                        children: "決済フォームの初期化に失敗しました。"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                        lineNumber: 562,
                                        columnNumber: 21
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/pos/PosCheckout.tsx",
                                    lineNumber: 541,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/pos/PosCheckout.tsx",
                            lineNumber: 493,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/pos/PosCheckout.tsx",
                    lineNumber: 410,
                    columnNumber: 11
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center justify-center h-full text-gray-400 text-xl",
                    children: "卓を選択してください"
                }, void 0, false, {
                    fileName: "[project]/src/components/pos/PosCheckout.tsx",
                    lineNumber: 569,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/pos/PosCheckout.tsx",
                lineNumber: 408,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/pos/PosCheckout.tsx",
        lineNumber: 373,
        columnNumber: 5
    }, this);
}
_s1(PosCheckout, "UsZpDpBGSDugWEddrJOMQ/TWLuU=");
_c1 = PosCheckout;
var _c, _c1;
__turbopack_context__.k.register(_c, "StripeCheckoutForm");
__turbopack_context__.k.register(_c1, "PosCheckout");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_1_bf4nm._.js.map